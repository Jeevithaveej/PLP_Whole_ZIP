package com.capgemini.capstore.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.capstore.beans.Admin;
import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.dao.ICustomerDao;
import com.capgemini.capstore.exceptions.CapStoreException;
import com.capgemini.capstore.util.Decryption;
import com.capgemini.capstore.util.Encryption;
import com.capgemini.capstore.util.Status;

@Service
public class CustomerServiceImpl implements ICustomerService{

	@Autowired
	ICustomerDao customerDao;

	@Override
	public Customer createAccount(Customer customer) {
		customer.setCustomerPassword(Encryption.encrypt(customer.getCustomerPassword()));
		customerDao.save(customer);
		return customerDao.findById(customer.getCustomerId()).get();
	}

	@Override
	public Customer viewById(long customerId) {
		Customer customer=  customerDao.findByCustomerId(customerId);
		customer.setCustomerPassword(Decryption.decrypt(customer.getCustomerPassword()));
		return customer;
	}

	@Override
	public boolean changePassword(long customerId, String oldPassword, String newPassword, Customer customer) throws CapStoreException {
		try{
			Optional<Customer> optional=customerDao.findById(customerId);
			if(optional.isPresent()) {
				if(Decryption.decrypt(optional.get().getCustomerPassword()).contains(oldPassword)) {
					customer=optional.get();
					customer.setCustomerId(optional.get().getCustomerId());
					customer.setCustomerName(optional.get().getCustomerName());
					customer.setCustomerPassword(Encryption.encrypt(newPassword));
					customer.setCustomerContactNo(optional.get().getCustomerContactNo());
					customer.setCustomerAddress(optional.get().getCustomerAddress());
					customer.setCustomerStatus(Status.ACTIVE);
					customerDao.save(customer);
					return true;
				}else {
					throw new CapStoreException("Please enter correct Old Password.");
				}
			}else {
				throw new CapStoreException("Account does not Exist.");
			}


		} catch (Exception e) {
			throw new CapStoreException("Something went wrong, Please try again after some time.");

		}

	}

}
