package com.capgemini.capstore.service;

import com.capgemini.capstore.beans.Customer;
import com.capgemini.capstore.exceptions.CapStoreException;

public interface ICustomerService {

	Customer createAccount(Customer customer);

	Customer viewById(long customerId);

	boolean changePassword(long customerId, String oldPassword, String newPassword, Customer customer) throws CapStoreException;

}
