package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.dao.IAdminCouponDao;

@Service("couponService")
public class AdminCouponServiceImpl implements AdminCouponService{

	@Autowired
	IAdminCouponDao admincouponDao;
	public Coupon checkIfCouponCodeIsValid(String couponCode) {
		Coupon myCoupon= admincouponDao.findByCouponCode(couponCode);
		if(myCoupon.equals(null)) {
			return null;
		}
		return myCoupon;
	}

	
	
	@Override
	public Coupon generateCoupon(Coupon coupon) {
		admincouponDao.save(coupon);
		return coupon;
	}

}
