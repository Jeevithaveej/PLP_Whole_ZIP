package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.capgemini.capstore.beans.Customer;

public interface ICustomerDao extends JpaRepository<Customer, Long> {

	@Query("from Customer where customerId=?1")
	Customer findByCustomerId(long customerId);

}
