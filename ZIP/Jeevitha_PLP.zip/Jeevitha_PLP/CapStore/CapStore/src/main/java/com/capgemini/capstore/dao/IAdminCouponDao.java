package com.capgemini.capstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.capstore.beans.Coupon;

public interface IAdminCouponDao extends JpaRepository<Coupon,Long>{

	Coupon findByCouponCode(String couponCode);

}
