package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.service.AdminCouponService;

@RestController
@RequestMapping("/admincoupon")
public class AdminCouponController {
	
	@Autowired
	AdminCouponService couponService;
	
	@PostMapping(value="/generateCoupon")
	public ResponseEntity<Coupon> generateCoupon(@RequestBody Coupon coupon) throws Exception{
	
		couponService.generateCoupon(coupon);
		
		return new ResponseEntity<Coupon>(coupon, HttpStatus.OK);
		
		
	}
	
	@GetMapping(value="/verifyingCoupon/{couponCode}")
	public ResponseEntity<Coupon> applyingCoupon(@PathVariable("couponCode") String couponCode)throws Exception{
		
		Coupon couponResponse = couponService.checkIfCouponCodeIsValid(couponCode);
	
		return new ResponseEntity<Coupon>(couponResponse,HttpStatus.OK);

	}
}
