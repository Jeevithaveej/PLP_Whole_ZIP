package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.beans.Coupon;
import com.capgemini.capstore.service.MerchantCouponService;

@RestController
@RequestMapping("/merchantcoupon")
public class MerchantCouponController {
	
	@Autowired
	MerchantCouponService mcouponService;
	
	@PostMapping(value="/generateCoupon")
	public ResponseEntity<Coupon> generateCoupon(@RequestBody Coupon coupon) throws Exception{
		
		mcouponService.generateCoupon(coupon);
		
		return new ResponseEntity<Coupon>(coupon, HttpStatus.OK);
		
	}
	
	@GetMapping(value="/verifyingCoupon/{couponCode}")
	public ResponseEntity<Coupon> applyingCoupon(@PathVariable("couponCode") String couponCode)throws Exception{
		
		Coupon couponResponse = mcouponService.checkIfCouponCodeIsValid(couponCode);
		
		return new ResponseEntity<Coupon>(couponResponse,HttpStatus.OK);

	}


}
