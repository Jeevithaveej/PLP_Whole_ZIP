import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MerchantcouponComponent } from './merchantcoupon.component';

describe('MerchantcouponComponent', () => {
  let component: MerchantcouponComponent;
  let fixture: ComponentFixture<MerchantcouponComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MerchantcouponComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MerchantcouponComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
