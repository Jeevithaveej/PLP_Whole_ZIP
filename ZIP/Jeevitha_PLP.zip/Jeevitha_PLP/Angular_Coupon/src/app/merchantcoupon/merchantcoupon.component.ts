import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-merchantcoupon',
  templateUrl: './merchantcoupon.component.html',
  styleUrls: ['./merchantcoupon.component.css']
})
export class MerchantcouponComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
