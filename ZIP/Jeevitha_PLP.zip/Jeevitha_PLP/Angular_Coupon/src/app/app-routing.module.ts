import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MerchantcouponComponent } from './merchantcoupon/merchantcoupon.component';
import { AdminCouponComponent } from './admin-coupon/admin-coupon.component';


const routes: Routes = [

  {
    path:'app-admin-coupon',
    component : AdminCouponComponent
  },
    {
    path:'app-merchantcoupon',
    component : MerchantcouponComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
