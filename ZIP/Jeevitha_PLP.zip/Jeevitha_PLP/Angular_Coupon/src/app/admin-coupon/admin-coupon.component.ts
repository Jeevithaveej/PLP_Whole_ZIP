import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-coupon',
  templateUrl: './admin-coupon.component.html',
  styleUrls: ['./admin-coupon.component.css']
})
export class AdminCouponComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
