import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup,Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-coupon',
  templateUrl: './admin-coupon.component.html',
  styleUrls: ['./admin-coupon.component.css']
})
export class AdminCouponComponent implements OnInit {

  couponGenerate: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.couponGenerate = this.formBuilder.group({
      couponId: ['', Validators.required],
      couponCode: ['', Validators.required],
      minAmount: ['', Validators.required],
      maxAmount: ['', Validators.required],
      discountPercent: ['', Validators.required],
      generationDate: ['', Validators.required],
      expiryDate: ['', Validators.required],
      
    });
}

// convenience getter for easy access to form fields
get f() { return this.couponGenerate.controls; }

onSubmit() {
    this.submitted = true;

   
    if (this.couponGenerate.invalid) {
        return;
    }

   
   alert('Coupon Generated Successfully!!   :-)\n\n')
}
}
