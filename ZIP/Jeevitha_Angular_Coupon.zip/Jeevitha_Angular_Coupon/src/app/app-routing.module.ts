import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminCouponComponent } from './admin-coupon/admin-coupon.component';


const routes: Routes = [

  {
    path:'app-admin-coupon',
    component : AdminCouponComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
